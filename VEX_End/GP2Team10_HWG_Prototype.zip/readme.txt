TEAM X - HWG

What's inside the Folder
1) Inside the HWG_Prototype_Art is the build which contains all of our art assets.
2) Within HWG_Prototype_GP contains the build which features the main experience of the Hallway with Guard game.


How to Play
1) After the game is launched, press the Play button!
2) The controls are laid out as W for Forward, S for Backwards, A for Left, and D for Right.
3) The mouse will allow the player to look around and analyze what is going on.
4) Once on the level, avoid the Reaper and find your way to the treasure that's hidden inside the maze!

Github Link 
1) https://github.com/Venyxx/VEX_End

Release Notes 2/19/22
1) Original 1.0 build with initial level design, coding, and art assets placed
A) Known Bugs 
   I) Enemy movement is choppy during navigation.
B) Miscellaneous 
   I) The beginning room and last room were not placed in as those had art assets to flesh those out.
   II) Collision with the enemy does not end the game, he will just push you endlessly.
